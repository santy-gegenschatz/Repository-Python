from setuptools import setup

setup(
    name='ecommerce',
    version='0.0.1',
    packages=['my_first_package'],
    author= 'Santy',
)